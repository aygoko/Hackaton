// main.js

let fio = document.querySelector('#FIO-input')
let studt = document.querySelector('#Stutd-input')
let fio_data = ' '

// Конкретные значения ФИО и номера студенческого
const validFio = ''
const validStudt = '41G0134'

let app = new Vue({
	el: '.main',
	data: {
		showRegister: true,
		showAnswer: false,
		invalidData: false,
		Fio_messag: '',
		studt_message: '',
	},
	methods: {
		goToRegister() {
			this.showRegister = true
			this.showAnswer = false
			this.invalidData = false
		},
		goToAnswer(Fio_messag, studt_message) {
				this.showRegister = false
				this.showAnswer = true
				this.invalidData = false
		},
	},
})

document.querySelector('#checkButton').addEventListener('click', function () {
	console.log(`FIO: ${fio_data}, Studt: ${studt.value}`)
	app.goToAnswer()
})

for (let i = 1; i <= 7; i++) {
	document
		.querySelector(`#copyButton-${i}`)
		.addEventListener('click', function () {
			var range = document.createRange()
			range.selectNode(document.querySelector(`#myDiv-${i}`))
			window.getSelection().removeAllRanges()
			window.getSelection().addRange(range)
			document.execCommand('copy')
			window.getSelection().removeAllRanges()
		})
}
